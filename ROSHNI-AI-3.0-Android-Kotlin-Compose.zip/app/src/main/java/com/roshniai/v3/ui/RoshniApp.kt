package com.roshniai.v3.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.roshniai.v3.model.*
import com.roshniai.v3.voice.VoiceAssistantHelper
import com.roshniai.v3.viewmodel.RoshniViewModel

enum class RoshniTab { CHAT, HISTORY, SETTINGS }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoshniApp(viewModel: RoshniViewModel) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsState()
    val messages by viewModel.activeMessages.collectAsState()
    val sessions by viewModel.sessions.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()

    var currentTab by remember { mutableStateOf(RoshniTab.CHAT) }
    var inputText by remember { mutableStateOf("") }
    var isListening by remember { mutableStateOf(false) }

    val voiceHelper = remember {
        VoiceAssistantHelper(
            context = context,
            onTranscriptResult = { transcript -> inputText = transcript },
            onListeningChanged = { active -> isListening = active }
        )
    }

    DisposableEffect(Unit) {
        onDispose { voiceHelper.shutdown() }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) voiceHelper.startListening(settings.language)
    }

    val isHindi = settings.language == AppLanguage.HINDI

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "ROSHNI AI 3.0",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                },
                actions = {
                    FilledTonalButton(
                        onClick = {
                            viewModel.startNewChat()
                            currentTab = RoshniTab.CHAT
                        },
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (isHindi) "नया चैट" else "New Chat")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = currentTab == RoshniTab.CHAT,
                    onClick = { currentTab = RoshniTab.CHAT },
                    icon = { Icon(Icons.Default.ChatBubbleOutline, contentDescription = null) },
                    label = { Text(if (isHindi) "चैट" else "Chat") }
                )
                NavigationBarItem(
                    selected = currentTab == RoshniTab.HISTORY,
                    onClick = { currentTab = RoshniTab.HISTORY },
                    icon = { Icon(Icons.Default.History, contentDescription = null) },
                    label = { Text(if (isHindi) "इतिहास" else "History") }
                )
                NavigationBarItem(
                    selected = currentTab == RoshniTab.SETTINGS,
                    onClick = { currentTab = RoshniTab.SETTINGS },
                    icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                    label = { Text(if (isHindi) "सेटिंग्स" else "Settings") }
                )
            }
        }
    ) { innerPadding ->
        when (currentTab) {
            RoshniTab.CHAT -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    LazyColumn(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (messages.isEmpty()) {
                            item {
                                Text(
                                    text = if (isHindi) "नमस्ते, आज रोशनी आपकी क्या सहायता करे?"
                                    else "Namaste, how can Roshni help today?",
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(vertical = 24.dp)
                                )
                            }
                        }
                        items(messages, key = { it.id }) { msg ->
                            val isUser = msg.role == "user"
                            Box(
                                modifier = Modifier.fillMaxWidth(),
                                contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(20.dp),
                                    color = if (isUser) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier.widthIn(max = 320.dp)
                                ) {
                                    Column(Modifier.padding(14.dp)) {
                                        Text(
                                            text = msg.content,
                                            color = if (isUser) MaterialTheme.colorScheme.onPrimary
                                            else MaterialTheme.colorScheme.onSurface
                                        )
                                        if (!isUser) {
                                            TextButton(
                                                onClick = {
                                                    voiceHelper.speak(
                                                        msg.content,
                                                        settings.language,
                                                        settings.speechRate
                                                    )
                                                },
                                                contentPadding = PaddingValues(0.dp)
                                            ) {
                                                Icon(Icons.Default.VolumeUp, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(Modifier.width(4.dp))
                                                Text(if (isHindi) "सुनें" else "Listen")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Bottom Message & Voice Composer
                    Surface(tonalElevation = 2.dp) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = {
                                    if (isListening) voiceHelper.stopListening()
                                    else micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            ) {
                                Icon(
                                    imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                                    contentDescription = "Voice Input",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                            OutlinedTextField(
                                value = inputText,
                                onValueChange = { inputText = it },
                                modifier = Modifier.weight(1f),
                                placeholder = {
                                    Text(if (isHindi) "संदेश लिखें..." else "Ask Roshni...")
                                },
                                shape = RoundedCornerShape(24.dp),
                                maxLines = 4
                            )
                            Spacer(Modifier.width(8.dp))
                            FilledIconButton(
                                onClick = {
                                    val prompt = inputText
                                    inputText = ""
                                    viewModel.sendMessage(prompt) { reply ->
                                        voiceHelper.speak(reply, settings.language, settings.speechRate)
                                    }
                                },
                                enabled = inputText.isNotBlank() && !isGenerating
                            ) {
                                Icon(Icons.Default.Send, contentDescription = "Send")
                            }
                        }
                    }
                }
            }

            RoshniTab.HISTORY -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(innerPadding),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(sessions, key = { it.id }) { session ->
                        Card(
                            onClick = {
                                viewModel.openSession(session.id)
                                currentTab = RoshniTab.CHAT
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(session.title, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
                                IconButton(onClick = { viewModel.deleteSession(session.id) }) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete")
                                }
                            }
                        }
                    }
                }
            }

            RoshniTab.SETTINGS -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    Text(
                        text = if (isHindi) "01. एआई मोड (ऑनलाइन / ऑफ़लाइन)" else "01. AI Mode (Online & Offline)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        FilterChip(
                            selected = settings.aiMode == AiMode.ONLINE,
                            onClick = { viewModel.updateAiMode(AiMode.ONLINE) },
                            label = { Text(if (isHindi) "ऑनलाइन Gemini AI" else "Online Gemini AI") }
                        )
                        FilterChip(
                            selected = settings.aiMode == AiMode.OFFLINE,
                            onClick = { viewModel.updateAiMode(AiMode.OFFLINE) },
                            label = { Text(if (isHindi) "ऑफ़लाइन AI" else "Offline AI") }
                        )
                    }

                    Text(
                        text = if (isHindi) "02. भाषा (हिन्दी / English)" else "02. Language",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        AppLanguage.entries.forEach { lang ->
                            FilterChip(
                                selected = settings.language == lang,
                                onClick = { viewModel.updateLanguage(lang) },
                                label = { Text(lang.displayName) }
                            )
                        }
                    }

                    Text(
                        text = if (isHindi) "03. थीम (लाइट / डार्क)" else "03. Theme",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        ThemeMode.entries.forEach { mode ->
                            FilterChip(
                                selected = settings.themeMode == mode,
                                onClick = { viewModel.updateTheme(mode) },
                                label = { Text(mode.name) }
                            )
                        }
                    }
                }
            }
        }
    }
}
