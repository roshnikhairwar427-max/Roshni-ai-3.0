package com.roshniai.v3.data

import com.roshniai.v3.model.AppLanguage
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

class OfflineAiEngine {

    private val dictionary = mapOf(
        "hello" to "नमस्ते (Namaste)",
        "thank you" to "धन्यवाद (Dhanyavaad)",
        "how are you" to "आप कैसे हैं? (Aap kaise hain?)",
        "where is the station" to "रेलवे स्टेशन कहाँ है? (Railway station kahan hai?)",
        "please help me" to "कृपया मेरी मदद करें (Kripaya meri madad karein)",
        "light" to "रोशनी / प्रकाश (Roshni)"
    )

    fun generateReply(prompt: String, language: AppLanguage): String {
        val clean = prompt.trim()
        val lower = clean.lowercase(Locale.ROOT)
        val isHindi = language == AppLanguage.HINDI || clean.any { it in '\u0900'..'\u097F' }

        // 1. Time & Date
        if (lower.contains("time") || lower.contains("date") || clean.contains("समय") || clean.contains("तारीख")) {
            val now = LocalDateTime.now()
            val formatted = now.format(DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a"))
            return if (isHindi) "वर्तमान ऑन-डिवाइस समय और दिनांक: $formatted"
            else "Current on-device date & time: $formatted"
        }

        // 2. GST Calculator (e.g., "18% GST on 12450")
        val gstRegex = Regex("(\\d+(?:\\.\\d+)?)\\s*%\\s*gst\\s*(?:on|of|पर)?\\s*(\\d+(?:\\.\\d+)?)", RegexOption.IGNORE_CASE)
        gstRegex.find(clean.replace(",", ""))?.let { match ->
            val rate = match.groupValues[1].toDouble()
            val base = match.groupValues[2].toDouble()
            val gst = (base * rate) / 100.0
            val total = base + gst
            return if (isHindi) {
                "GST गणना ($rate%):\n• मूल राशि: ₹%.2f\n• कुल GST: ₹%.2f\n• कुल राशि: ₹%.2f".format(base, gst, total)
            } else {
                "GST Calculation ($rate%):\n• Base: ₹%.2f\n• GST: ₹%.2f\n• Grand Total: ₹%.2f".format(base, gst, total)
            }
        }

        // 3. Distance Conversion (km to miles)
        Regex("(-?\\d+(?:\\.\\d+)?)\\s*km\\s*(?:to|in)?\\s*miles", RegexOption.IGNORE_CASE)
            .find(lower)?.let { m ->
                val km = m.groupValues[1].toDouble()
                val miles = km * 0.621371
                return if (isHindi) "$km किमी = %.2f मील".format(miles)
                else "$km km = %.2f miles".format(miles)
            }

        // 4. Bilingual Phrasebook
        val matched = dictionary.entries.filter { (en, hi) ->
            lower.contains(en) || clean.contains(hi.substringBefore(" "))
        }
        if (matched.isNotEmpty()) {
            return matched.joinToString("\n") { "• ${it.key} ↔ ${it.value}" }
        }

        return if (isHindi) {
            "ROSHNI AI 3.0 अभी ऑफ़लाइन मोड में है। आप गणित (जैसे '18% GST on 5000'), किमी-मील रूपांतरण, या शब्द अनुवाद पूछ सकते हैं। विस्तृत उत्तरों के लिए सेटिंग्स में ऑनलाइन AI मोड चुनें।"
        } else {
            "ROSHNI AI 3.0 is in Offline Mode. Try GST calculations ('18% GST on 5000'), km-to-miles conversions, or Hindi phrase translations — or switch to Online AI mode in Settings for full Gemini answers."
        }
    }
}
