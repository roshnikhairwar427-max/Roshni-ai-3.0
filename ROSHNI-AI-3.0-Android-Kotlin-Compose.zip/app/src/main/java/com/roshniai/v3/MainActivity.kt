package com.roshniai.v3

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.roshniai.v3.ui.RoshniApp
import com.roshniai.v3.ui.theme.RoshniTheme
import com.roshniai.v3.viewmodel.RoshniViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val roshniViewModel: RoshniViewModel = viewModel()
            val settings by roshniViewModel.settings.collectAsState()

            RoshniTheme(themeMode = settings.themeMode) {
                RoshniApp(viewModel = roshniViewModel)
            }
        }
    }
}
