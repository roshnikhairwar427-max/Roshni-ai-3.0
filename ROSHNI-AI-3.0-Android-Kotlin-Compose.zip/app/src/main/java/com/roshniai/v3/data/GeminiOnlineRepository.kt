package com.roshniai.v3.data

import com.roshniai.v3.BuildConfig
import com.roshniai.v3.model.AppLanguage
import com.roshniai.v3.model.ChatMessageEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiOnlineRepository {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun fetchOnlineReply(
        history: List<ChatMessageEntity>,
        language: AppLanguage
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val messagesArray = JSONArray()
            history.forEach { msg ->
                messagesArray.put(
                    JSONObject().apply {
                        put("role", msg.role)
                        put("content", msg.content)
                    }
                )
            }

            val payload = JSONObject().apply {
                put("language", if (language == AppLanguage.HINDI) "hi" else "en")
                put("messages", messagesArray)
            }

            val request = Request.Builder()
                .url("${BuildConfig.API_BASE_URL}/api/chat")
                .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val err = runCatching { JSONObject(body).optString("error") }.getOrDefault("")
                    throw IllegalStateException(err.ifBlank { "HTTP ${response.code}" })
                }
                JSONObject(body).optString("text", "")
            }
        }
    }
}
