package com.roshniai.v3.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.roshniai.v3.data.GeminiOnlineRepository
import com.roshniai.v3.data.OfflineAiEngine
import com.roshniai.v3.data.RoshniDatabase
import com.roshniai.v3.model.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalCoroutinesApi::class)
class RoshniViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = RoshniDatabase.getInstance(application).chatDao()
    private val onlineRepo = GeminiOnlineRepository()
    private val offlineEngine = OfflineAiEngine()

    private val _settings = MutableStateFlow(RoshniSettings())
    val settings: StateFlow<RoshniSettings> = _settings.asStateFlow()

    private val _activeSessionId = MutableStateFlow(UUID.randomUUID().toString())
    val activeSessionId: StateFlow<String> = _activeSessionId.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    val sessions: StateFlow<List<ChatSessionEntity>> = dao.observeSessions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeMessages: StateFlow<List<ChatMessageEntity>> = _activeSessionId
        .flatMapLatest { id -> dao.observeMessages(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun startNewChat() {
        _activeSessionId.value = UUID.randomUUID().toString()
    }

    fun openSession(sessionId: String) {
        _activeSessionId.value = sessionId
    }

    fun updateAiMode(mode: AiMode) {
        _settings.update { it.copy(aiMode = mode) }
    }

    fun updateLanguage(language: AppLanguage) {
        _settings.update { it.copy(language = language) }
    }

    fun updateTheme(theme: ThemeMode) {
        _settings.update { it.copy(themeMode = theme) }
    }

    fun toggleAutoSpeak(enabled: Boolean) {
        _settings.update { it.copy(autoSpeakReplies = enabled) }
    }

    fun deleteSession(sessionId: String) {
        viewModelScope.launch {
            dao.deleteMessagesForSession(sessionId)
            dao.deleteSession(sessionId)
            if (_activeSessionId.value == sessionId) startNewChat()
        }
    }

    fun sendMessage(prompt: String, onSpeakReply: ((String) -> Unit)? = null) {
        val clean = prompt.trim()
        if (clean.isEmpty() || _isGenerating.value) return

        viewModelScope.launch {
            val sessionId = _activeSessionId.value
            val currentSettings = _settings.value
            val existing = activeMessages.value

            if (existing.isEmpty()) {
                dao.upsertSession(
                    ChatSessionEntity(
                        id = sessionId,
                        title = clean.take(42),
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }

            val userMsg = ChatMessageEntity(
                id = UUID.randomUUID().toString(),
                sessionId = sessionId,
                role = "user",
                content = clean,
                mode = currentSettings.aiMode.name
            )
            dao.insertMessage(userMsg)
            _isGenerating.value = true

            val replyText = if (currentSettings.aiMode == AiMode.ONLINE) {
                onlineRepo.fetchOnlineReply(existing + userMsg, currentSettings.language)
                    .getOrElse { err ->
                        offlineEngine.generateReply(clean, currentSettings.language) +
                            "\n\n(Note: Online request failed: ${err.message})"
                    }
            } else {
                offlineEngine.generateReply(clean, currentSettings.language)
            }

            val assistantMsg = ChatMessageEntity(
                id = UUID.randomUUID().toString(),
                sessionId = sessionId,
                role = "model",
                content = replyText,
                mode = currentSettings.aiMode.name
            )
            dao.insertMessage(assistantMsg)
            _isGenerating.value = false

            if (currentSettings.autoSpeakReplies) {
                onSpeakReply?.invoke(replyText)
            }
        }
    }
}
