package com.roshniai.v3.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class AiMode { ONLINE, OFFLINE }

enum class AppLanguage(val localeTag: String, val displayName: String) {
    ENGLISH("en-IN", "English"),
    HINDI("hi-IN", "हिन्दी")
}

enum class ThemeMode { LIGHT, DARK, SYSTEM }

@Entity(tableName = "chat_sessions")
data class ChatSessionEntity(
    @PrimaryKey val id: String,
    val title: String,
    val pinned: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val sessionId: String,
    val role: String, // "user" or "model"
    val content: String,
    val mode: String, // "ONLINE" or "OFFLINE"
    val timestamp: Long = System.currentTimeMillis()
)

data class RoshniSettings(
    val aiMode: AiMode = AiMode.ONLINE,
    val language: AppLanguage = AppLanguage.ENGLISH,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val autoSpeakReplies: Boolean = false,
    val speechRate: Float = 1.0f
)
