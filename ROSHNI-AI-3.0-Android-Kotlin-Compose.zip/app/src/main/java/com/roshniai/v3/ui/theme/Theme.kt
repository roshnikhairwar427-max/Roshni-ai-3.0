package com.roshniai.v3.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.roshniai.v3.model.ThemeMode

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFFD95D24),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFFEDE5),
    onPrimaryContainer = Color(0xFF421400),
    background = Color(0xFFFAF9F6),
    onBackground = Color(0xFF1C1917),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1C1917),
    surfaceVariant = Color(0xFFF3F1EC),
    onSurfaceVariant = Color(0xFF57534E),
    outline = Color(0xFFE7E5E4)
)

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFF27D42),
    onPrimary = Color(0xFF2B0B00),
    primaryContainer = Color(0xFF5C2206),
    onPrimaryContainer = Color(0xFFFFDBCC),
    background = Color(0xFF0F1117),
    onBackground = Color(0xFFF1F5F9),
    surface = Color(0xFF171A23),
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = Color(0xFF1E2430),
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = Color(0xFF2B3242)
)

@Composable
fun RoshniTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    val useDark = when (themeMode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    MaterialTheme(
        colorScheme = if (useDark) DarkColorScheme else LightColorScheme,
        content = content
    )
}
