# ROSHNI AI 3.0 — Android Kotlin & Jetpack Compose Project

## Architecture Highlights
- **UI**: Material 3 Jetpack Compose (`RoshniApp.kt`, `Theme.kt`) with Light & Dark themes.
- **Online AI**: `GeminiOnlineRepository.kt` connecting to the Gemini 3.8 Flash backend proxy.
- **Offline AI**: `OfflineAiEngine.kt` providing 100% on-device GST/math calculations, unit conversions, and Hindi-English dictionary.
- **Bilingual**: English (`en-IN`) and Hindi (`hi-IN` देवनागरी) UI, SpeechRecognizer, and TextToSpeech (`VoiceAssistantHelper.kt`).
- **Chat History**: Persistent local SQLite storage with AndroidX Room (`ChatDatabase.kt`).

## Opening in Android Studio
1. Extract this archive into a folder named `RoshniAI3`.
2. Open the folder in Android Studio (Ladybug or newer).
3. Update `API_BASE_URL` in `app/build.gradle.kts` to point to your deployed ROSHNI AI 3.0 backend URL.
4. Sync Gradle and run on an Android 8.0+ (API 26+) device or emulator.